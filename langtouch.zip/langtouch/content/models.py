from django.db import models
from django.utils import timezone
from django.conf import settings
from django.utils.text import slugify
from django.urls import reverse

class Testimonial(models.Model):
    LANGUAGE_CHOICES = [
        ('en', 'English'),
        ('sw', 'Swahili'),
        ('fr', 'French'),
    ]

    client_name = models.CharField(max_length=255)
    quote = models.TextField()
    language = models.CharField(max_length=10, choices=LANGUAGE_CHOICES)
    video_url = models.URLField(blank=True, null=True)
    rating = models.PositiveSmallIntegerField(default=5)  # New field
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.client_name} ({self.language})"



class BlogPost(models.Model):
    LANGUAGE_CHOICES = [
        ('en', 'English'),
        ('sw', 'Swahili'),
        ('fr', 'French'),
        ('es', 'Spanish'),
        ('de', 'German'),
        ('ar', 'Arabic'),
    ]
    
    CATEGORY_CHOICES = [
        ('translation', 'Translation Tips'),
        ('grammar', 'Grammar Guide'),
        ('vocabulary', 'Vocabulary'),
        ('culture', 'Cultural Insights'),
        ('learning', 'Learning Methods'),
        ('news', 'Language News'),
        ('tech', 'Language Technology'),
    ]

    # Basic Fields
    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, max_length=300)
    excerpt = models.TextField(max_length=500, blank=True, help_text="Brief summary for preview cards")
    content = models.TextField()
    language = models.CharField(max_length=10, choices=LANGUAGE_CHOICES)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, default='learning')
    
    # Media
    cover_image_url = models.URLField(blank=True, null=True, help_text="URL for the blog cover image")
    cover_image_alt = models.CharField(max_length=200, blank=True, help_text="Alt text for accessibility and SEO")
    featured = models.BooleanField(default=False, help_text="Feature this post on homepage")
    
    # SEO Fields
    meta_title = models.CharField(max_length=200, blank=True, 
                                   help_text="Optional custom title for SEO (defaults to title if empty)")
    meta_description = models.CharField(max_length=300, blank=True, 
                                         help_text="Brief description for search engines and social sharing")
    meta_keywords = models.CharField(max_length=200, blank=True, 
                                      help_text="Comma-separated keywords for SEO")
    og_image_url = models.URLField(blank=True, null=True, 
                                   help_text="Custom Open Graph image for social sharing")
    
    # Status and Dates
    STATUS_CHOICES = [
        ('draft', 'Draft'),
        ('published', 'Published'),
        ('archived', 'Archived'),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    published_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, 
                                   related_name='blog_posts')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Statistics
    views = models.PositiveIntegerField(default=0)
    read_time = models.PositiveIntegerField(default=0, help_text="Estimated reading time in minutes")
    
    # Related Content
    related_posts = models.ManyToManyField('self', blank=True, symmetrical=False, 
                                           help_text="Select related blog posts")
    tags = models.CharField(max_length=200, blank=True, 
                            help_text="Comma-separated tags for better organization")

    class Meta:
        ordering = ['-published_at', '-created_at']
        verbose_name = 'Blog Post'
        verbose_name_plural = 'Blog Posts'
        indexes = [
            models.Index(fields=['status', 'published_at']),
            models.Index(fields=['language', 'category']),
            models.Index(fields=['slug']),
        ]

    def __str__(self):
        return f"{self.title} ({self.get_language_display()})"

    def save(self, *args, **kwargs):
        # Auto-generate slug if empty
        if not self.slug:
            self.slug = slugify(self.title[:250])
        
        # Set published time when status changes to published
        if self.status == 'published' and not self.published_at:
            self.published_at = timezone.now()
        
        # Auto-generate excerpt if empty (first 150 characters of content)
        if not self.excerpt:
            self.excerpt = self.content[:497] + '...' if len(self.content) > 500 else self.content
        
        # Calculate estimated read time (assuming 200 words per minute)
        word_count = len(self.content.split())
        self.read_time = max(1, round(word_count / 200))
        
        # Ensure slug uniqueness
        original_slug = self.slug
        counter = 1
        while BlogPost.objects.filter(slug=self.slug).exclude(pk=self.pk).exists():
            self.slug = f"{original_slug}-{counter}"
            counter += 1
        
        # Auto-generate meta fields if empty
        if not self.meta_title:
            self.meta_title = self.title[:200]
        
        if not self.meta_description:
            self.meta_description = self.excerpt[:300]
        
        super().save(*args, **kwargs)

    def get_absolute_url(self):
        return reverse('content:blog_detail', kwargs={'slug': self.slug})

    def get_seo_context(self):
        """Return SEO context for templates"""
        return {
            'title': self.meta_title or self.title,
            'description': self.meta_description or self.excerpt,
            'keywords': self.meta_keywords,
            'og_image': self.og_image_url or self.cover_image_url,
            'url': self.get_absolute_url(),
            'type': 'article',
            'published_time': self.published_at.isoformat() if self.published_at else None,
            'modified_time': self.updated_at.isoformat(),
            'author': self.created_by.get_full_name() or self.created_by.username,
            'section': self.get_category_display(),
            'tags': [tag.strip() for tag in self.tags.split(',')] if self.tags else [],
        }

    def get_related_posts_list(self, limit=3):
        """Get list of related posts with fallback to same category/language"""
        related = self.related_posts.filter(status='published').exclude(pk=self.pk)
        
        if not related.exists():
            # Fallback: get posts with same category and language
            related = BlogPost.objects.filter(
                status='published',
                category=self.category,
                language=self.language
            ).exclude(pk=self.pk)
        
        return related[:limit]

    def increment_views(self):
        """Increment view count"""
        self.views += 1
        self.save(update_fields=['views'])

    @property
    def is_published(self):
        return self.status == 'published' and self.published_at is not None

    @property
    def tag_list(self):
        """Return tags as list"""
        if self.tags:
            return [tag.strip() for tag in self.tags.split(',')]
        return []

    @classmethod
    def get_featured_posts(cls, limit=3):
        """Get featured published posts"""
        return cls.objects.filter(
            status='published',
            featured=True,
            published_at__lte=timezone.now()
        )[:limit]

    @classmethod
    def get_recent_posts(cls, limit=5, language=None):
        """Get recent published posts optionally filtered by language"""
        queryset = cls.objects.filter(
            status='published',
            published_at__lte=timezone.now()
        )
        
        if language:
            queryset = queryset.filter(language=language)
        
        return queryset[:limit]
    

class BlogComment(models.Model):
    post = models.ForeignKey(BlogPost, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    content = models.TextField(max_length=1000)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, 
                               related_name='replies')
    approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']
        
    def __str__(self):
        return f"Comment by {self.author} on {self.post.title[:50]}"
    

class NewsletterSubscriber(models.Model):
    email = models.EmailField(unique=True)
    subscribed_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.email
    

class Video(models.Model):
    SECTION_CHOICES = [
        ('A1-A2', 'A1 - A2 Beginner'),
        ('B1-B2', 'B1 - B2 Intermediate'),
        ('C1-C2', 'C1 - C2 Advanced'),
    ]

    LANGUAGE_CHOICES = [
        ('English', 'English'),
        ('Swahili', 'Swahili'),
        ('French', 'French'),
    ]

    title = models.CharField(max_length=255)
    url = models.URLField(help_text="Paste a YouTube/Vimeo embed URL")
    description = models.TextField(blank=True, help_text="Add details or notes about this video")
    section = models.CharField(max_length=20, choices=SECTION_CHOICES)
    language = models.CharField(max_length=50, choices=LANGUAGE_CHOICES)
    price = models.DecimalField(max_digits=8, decimal_places=2, default=0.00)  # 💰 add this
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.language} - {self.section})"



class VideoPurchase(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    video = models.ForeignKey(Video, on_delete=models.CASCADE)
    payment = models.ForeignKey('payments.Payment', on_delete=models.CASCADE, null=True, blank=True)
    purchased_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'video')  # prevent double purchases

    def __str__(self):
        return f"{self.user} bought {self.video}"
