from django.contrib import admin
from .models import Testimonial, BlogPost, NewsletterSubscriber

@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ('client_name', 'language', 'rating', 'created_at')
    list_filter = ('language', 'rating')
    search_fields = ('client_name', 'quote')

@admin.register(BlogPost)
class BlogPostAdmin(admin.ModelAdmin):
    list_display = ('title', 'language', 'published_at', 'created_by', 'created_at')
    list_filter = ('language', 'published_at', 'created_by')
    search_fields = ('title', 'content')
    prepopulated_fields = {'slug': ('title',)}  # auto-generate slug
    ordering = ('-published_at',)
    date_hierarchy = 'published_at'

@admin.register(NewsletterSubscriber)
class NewsletterSubscriberAdmin(admin.ModelAdmin):
    list_display = ('email', 'subscribed_at')
    search_fields = ('email',)


from .models import Video

@admin.register(Video)
class VideoAdmin(admin.ModelAdmin):
    list_display = ['title', 'language', 'section', 'price', 'created_at']
    list_filter = ['language', 'section']
    search_fields = ['title', 'description']
    ordering = ['-created_at']
    
    fieldsets = (
        (None, {
            'fields': ('title', 'url', 'description', 'section', 'language', 'price')
        }),
    )

