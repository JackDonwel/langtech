from django.urls import path
from . import views

app_name = "content"

urlpatterns = [
    path('blog/', views.blog_list, name='blog_list'),
    path('blog/category/<str:category>/', views.blog_list, name='blog_list_by_category'),
    path('blog/language/<str:language>/', views.blog_list, name='blog_list_by_language'),
    path('newsletter/subscribe/', views.newsletter_subscribe, name='newsletter_subscribe'),
    path('blog/new/', views.blog_create, name='blog_create'),
    path('blog/<slug:slug>/', views.blog_detail, name='blog_detail'),
    path('subscribe/', views.subscribe_newsletter, name='subscribe_newsletter'),
    path('testimonials/', views.testimonials_list, name='testimonials_list'),
    path('videos/', views.video_learning, name='video_learning'),
    path('buy-video/<int:video_id>/', views.buy_video, name='buy_video'),

]
