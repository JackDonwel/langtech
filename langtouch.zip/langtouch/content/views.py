from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings


from .models import (
    BlogPost,
    Testimonial,
    Video,
    VideoPurchase
)

from .forms import BlogPostForm, NewsletterSubscriberForm

from payments.models import PaymentMethod, Payment, Currency


# --------------------------------------------------
# Blog Views
# --------------------------------------------------

def blog_list(request):
    posts_list = BlogPost.objects.filter(
        status='published',
        published_at__lte=timezone.now()
    ).order_by('-published_at')
    
    # Language filter
    language = request.GET.get('language')
    if language:
        posts_list = posts_list.filter(language=language)
    
    # Category filter
    category = request.GET.get('category')
    if category:
        posts_list = posts_list.filter(category=category)
    
    # Search query
    query = request.GET.get('q')
    if query:
        posts_list = posts_list.filter(
            Q(title__icontains=query) |
            Q(content__icontains=query) |
            Q(excerpt__icontains=query) |
            Q(tags__icontains=query)
        )
    
    # Featured posts
    featured_posts = BlogPost.get_featured_posts(3)
    
    # Pagination
    paginator = Paginator(posts_list, 9)
    page = request.GET.get('page')

    try:
        posts = paginator.page(page)
    except (PageNotAnInteger, EmptyPage):
        posts = paginator.page(1)

    # Language & category choices
    LANGUAGE_CHOICES = BlogPost.LANGUAGE_CHOICES
    CATEGORY_CHOICES = BlogPost.CATEGORY_CHOICES
    
    context = {
        'posts': posts,
        'featured_posts': featured_posts,
        'query': query,

        'selected_language': language,
        'selected_language_name': dict(LANGUAGE_CHOICES).get(language, ''),

        'selected_category': category,
        'selected_category_name': dict(CATEGORY_CHOICES).get(category, ''),

        'LANGUAGE_CHOICES': LANGUAGE_CHOICES,
        'CATEGORY_CHOICES': CATEGORY_CHOICES,
    }
    
    return render(request, 'content/blog_list.html', context)


def newsletter_subscribe(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        
        # Here you would save to database
        # NewsletterSubscriber.objects.create(email=email)
        
        # Send confirmation email (optional)
        send_mail(
            'Welcome to LangTouch Newsletter!',
            'Thank you for subscribing to our language learning newsletter.',
            settings.DEFAULT_FROM_EMAIL,
            [email],
            fail_silently=True,
        )
        
        messages.success(request, 'Thank you for subscribing!')
        return redirect('content:blog_list')
    
    return redirect('content:blog_list')

def blog_detail(request, slug):
    post = get_object_or_404(BlogPost, slug=slug, published_at__isnull=False)
    return render(request, 'content/blog_detail.html', {'post': post})

def blog_create(request):
    if request.method == 'POST':
        form = BlogPostForm(request.POST)
        if form.is_valid():
            blog = form.save(commit=False)
            blog.created_by = request.user
            blog.published_at = timezone.now()
            blog.save()
            return redirect('blog_list')
    else:
        form = BlogPostForm()
    return render(request, 'content/blog_form.html', {'form': form})

# Newsletter
def subscribe_newsletter(request):
    if request.method == 'POST':
        form = NewsletterSubscriberForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('blog_list')
    else:
        form = NewsletterSubscriberForm()
    return render(request, 'content/subscribe.html', {'form': form})

# Testimonials
def testimonials_list(request):
    testimonials = Testimonial.objects.all().order_by('-created_at')
    return render(request, 'content/testimonials.html', {'testimonials': testimonials})

from .models import Video


def video_learning(request):
    language = request.GET.get('language', 'English')
    videos = Video.objects.filter(language=language).order_by('section')

    sections = {}
    for v in videos:
        purchased = False
        if request.user.is_authenticated:
            # ✅ Check if user has confirmed payment for this video
            purchased = Payment.objects.filter(
                user=request.user,
                video=v,
                is_confirmed=True,
                status="Completed"
            ).exists()

        v.is_purchased = purchased
        sections.setdefault(v.section, []).append(v)

    return render(request, 'content/video_learning.html', {
        'sections': sections,
        'current_language': language,
        'languages': ['English', 'Swahili', 'French'],
    })


def buy_video(request, video_id):
    video = get_object_or_404(Video, id=video_id)
    if request.user.is_authenticated:
        currency = Currency.objects.filter(is_default=True).first()
        method = PaymentMethod.objects.first()

        if not currency or not method:
            # Safety net to avoid IntegrityError
            messages.error(request, "No currency or payment method configured. Please contact admin.")
            return redirect('content:video_learning')

        payment = Payment.objects.create(
            user=request.user,
            amount=video.price,
            currency=currency,
            method=method,
            reference_number=f"VID-{request.user.id}-{timezone.now().timestamp()}",
            status='Completed',
        )
        VideoPurchase.objects.create(user=request.user, video=video, payment=payment)
        return redirect('content:video_learning')
    return redirect('login')
