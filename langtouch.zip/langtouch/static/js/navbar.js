        document.addEventListener('DOMContentLoaded', () => {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            const hamburgerIcon = document.querySelector('.hamburger-icon');
            const openAssistantDesktopButton = document.getElementById('open-assistant-desktop');
            const openAssistantMobileButton = document.getElementById('open-assistant-mobile');
            const geminiAssistantModal = document.getElementById('gemini-assistant-modal');
            const closeAssistantModalButton = document.getElementById('close-assistant-modal');
            const assistantInput = document.getElementById('assistant-input');
            const generateResponseButton = document.getElementById('generate-response-button');
            const loadingIndicator = document.getElementById('loading-indicator');
            const assistantResponse = document.getElementById('assistant-response');

            // Toggle mobile menu visibility
            mobileMenuButton.addEventListener('click', () => {
                mobileMenu.classList.toggle('hidden');
                hamburgerIcon.classList.toggle('open');
            });

            // Close mobile menu when a link is clicked
            mobileMenu.querySelectorAll('a').forEach(link => {
                link.addEventListener('click', () => {
                    mobileMenu.classList.add('hidden');
                    hamburgerIcon.classList.remove('open');
                });
            });

            // Open Gemini Assistant Modal
            openAssistantDesktopButton.addEventListener('click', () => {
                geminiAssistantModal.classList.remove('hidden');
            });

            openAssistantMobileButton.addEventListener('click', () => {
                geminiAssistantModal.classList.remove('hidden');
                mobileMenu.classList.add('hidden'); // Close mobile menu when modal opens
                hamburgerIcon.classList.remove('open');
            });

            // Close Gemini Assistant Modal
            closeAssistantModalButton.addEventListener('click', () => {
                geminiAssistantModal.classList.add('hidden');
                assistantInput.value = ''; // Clear input on close
                assistantResponse.textContent = 'Your AI assistant is ready!'; // Reset response
            });

            // Close modal when clicking outside of it
            geminiAssistantModal.addEventListener('click', (e) => {
                if (e.target === geminiAssistantModal) {
                    geminiAssistantModal.classList.add('hidden');
                    assistantInput.value = ''; // Clear input on close
                    assistantResponse.textContent = 'Your AI assistant is ready!'; // Reset response
                }
            });

            // Gemini API Integration
            generateResponseButton.addEventListener('click', async () => {
                const prompt = assistantInput.value.trim();
                if (!prompt) {
                    assistantResponse.textContent = 'Please enter a prompt!';
                    return;
                }

                loadingIndicator.classList.remove('hidden');
                generateResponseButton.disabled = true;
                assistantResponse.textContent = ''; // Clear previous response

                let chatHistory = [];
                chatHistory.push({ role: "user", parts: [{ text: prompt }] });
                const payload = { contents: chatHistory };
                const apiKey = "AIzaSyDvHwQ28jOMh47vhdKLKI1F7xKkklML9qE";
                const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;

                let retries = 0;
                const maxRetries = 5;
                const baseDelay = 1000; // 1 second

                while (retries < maxRetries) {
                    try {
                        const response = await fetch(apiUrl, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });

                        if (response.status === 429) { // Too Many Requests
                            const delay = baseDelay * Math.pow(2, retries) + Math.random() * 1000; // Exponential backoff with jitter
                            retries++;
                            await new Promise(res => setTimeout(res, delay));
                            continue; // Retry the request
                        }

                        if (!response.ok) {
                            const errorData = await response.json();
                            throw new Error(`API error: ${response.status} ${response.statusText} - ${JSON.stringify(errorData)}`);
                        }

                        const result = await response.json();

                        if (result.candidates && result.candidates.length > 0 &&
                            result.candidates[0].content && result.candidates[0].content.parts &&
                            result.candidates[0].content.parts.length > 0) {
                            const text = result.candidates[0].content.parts[0].text;
                            assistantResponse.textContent = text;
                        } else {
                            assistantResponse.textContent = 'No response from AI assistant. Please try again.';
                        }
                        break; // Exit loop on success
                    } catch (error) {
                        console.error('Error calling Gemini API:', error);
                        assistantResponse.textContent = `Error: ${error.message}. Please try again.`;
                        break; // Exit loop on unrecoverable error
                    }
                }

                loadingIndicator.classList.add('hidden');
                generateResponseButton.disabled = false;
            });
        });