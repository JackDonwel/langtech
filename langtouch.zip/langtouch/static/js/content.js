 document.addEventListener('DOMContentLoaded', function() {
        // Auto-focus first input field
        const firstInput = document.querySelector('input, textarea, select');
        if (firstInput) firstInput.focus();
        
        // Add floating labels effect
        const formInputs = document.querySelectorAll('input, textarea, select');
        formInputs.forEach(input => {
            // Initialize on page load
            if (input.value !== '') {
                input.parentElement.classList.add('has-value');
            }
            
            input.addEventListener('input', function() {
                if (this.value !== '') {
                    this.parentElement.classList.add('has-value');
                } else {
                    this.parentElement.classList.remove('has-value');
                }
            });
        });
        
        // Star rating hover effects
        const stars = document.querySelectorAll('.star-option');
        stars.forEach(star => {
            star.addEventListener('mouseover', function() {
                const currentStar = this;
                let currentIndex = 0;
                let found = false;
                
                // Highlight current star and all previous stars
                stars.forEach((s, index) => {
                    if (s === currentStar) {
                        found = true;
                        currentIndex = index;
                    }
                    
                    if (!found) {
                        s.querySelector('label').style.color = '#ffc107';
                    } else if (s === currentStar) {
                        s.querySelector('label').style.color = '#ffc107';
                    } else {
                        s.querySelector('label').style.color = '#ddd';
                    }
                });
            });
            
            star.addEventListener('mouseout', function() {
                // Restore based on selected rating
                const selected = document.querySelector('.star-option input[type="radio"]:checked');
                if (selected) {
                    const selectedIndex = Array.from(stars).findIndex(s => 
                        s.querySelector('input') === selected
                    );
                    
                    stars.forEach((s, index) => {
                        if (index <= selectedIndex) {
                            s.querySelector('label').style.color = '#ffc107';
                        } else {
                            s.querySelector('label').style.color = '#ddd';
                        }
                    });
                } else {
                    stars.forEach(s => {
                        s.querySelector('label').style.color = '#ddd';
                    });
                }
            });
        });
        
        // Initialize star colors
        const selected = document.querySelector('.star-option input[type="radio"]:checked');
        if (selected) {
            const selectedIndex = Array.from(stars).findIndex(s => 
                s.querySelector('input') === selected
            );
            
            stars.forEach((s, index) => {
                if (index <= selectedIndex) {
                    s.querySelector('label').style.color = '#ffc107';
                } else {
                    s.querySelector('label').style.color = '#ddd';
                }
            });
        }
        
        // Update stars when a rating is selected
        document.querySelectorAll('.star-option input[type="radio"]').forEach(radio => {
            radio.addEventListener('change', function() {
                const selectedIndex = Array.from(stars).findIndex(s => 
                    s.querySelector('input') === this
                );
                
                stars.forEach((s, index) => {
                    if (index <= selectedIndex) {
                        s.querySelector('label').style.color = '#ffc107';
                    } else {
                        s.querySelector('label').style.color = '#ddd';
                    }
                });
            });
        });
    });