// static/js/ai.js
document.addEventListener('DOMContentLoaded', () => {
    const openAIButton = document.getElementById('open-ai-assistant');
    const aiModal = document.getElementById('AI-assistant-modal');
    const closeButton = document.getElementById('close-assistant-modal');
    const assistantInput = document.getElementById('assistant-input');
    const generateBtn = document.getElementById('generate-response-button');
    const loadingIndicator = document.getElementById('loading-indicator');
    const assistantResponse = document.getElementById('assistant-response');

    // ⚠️ Exposing API key in JS is not safe for production!
    const apiKey = "AIzaSyDvHwQ28jOMh47vhdKLKI1F7xKkklML9qE";

    // ✅ FIXED MODEL NAME
    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;

    const resetModal = () => {
        if (assistantInput) assistantInput.value = '';
        if (assistantResponse) assistantResponse.textContent = 'Your AI assistant is ready!';
    };

    openAIButton?.addEventListener('click', () => {
        aiModal?.classList.remove('hidden');
        resetModal();
    });

    closeButton?.addEventListener('click', () => {
        aiModal?.classList.add('hidden');
        resetModal();
    });

    aiModal?.addEventListener('click', (e) => {
        if (e.target === aiModal) {
            aiModal?.classList.add('hidden');
            resetModal();
        }
    });

    generateBtn?.addEventListener('click', async () => {
        const prompt = assistantInput?.value.trim();
        if (!prompt) {
            assistantResponse.textContent = 'Please enter a prompt!';
            return;
        }

        loadingIndicator?.classList.remove('hidden');
        generateBtn.disabled = true;
        assistantResponse.textContent = '';

        const payload = {
            contents: [{
                role: "user",
                parts: [{ text: prompt }]
            }]
        };

        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(`API error: ${response.status} - ${response.statusText}. Details: ${JSON.stringify(errorData)}`);
            }

            const result = await response.json();
            const text = result?.candidates?.[0]?.content?.parts?.[0]?.text;

            assistantResponse.textContent = text || 'No response from AI assistant. Please try again.';
        } catch (error) {
            console.error('Gemini API error:', error);
            assistantResponse.textContent = `Error: ${error.message}. Please try again.`;
        } finally {
            loadingIndicator?.classList.add('hidden');
            generateBtn.disabled = false;
        }
    });
});
