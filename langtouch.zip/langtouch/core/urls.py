# core/urls.py
from django.urls import path
from django.shortcuts import render
from . import views
from django.views.generic import RedirectView

app_name = 'core'

urlpatterns = [
    # API endpoints
    path('api/ai-chat/', views.api_ai_chat, name='api_ai_chat'),

    # Message-related routes
    path('message/<uuid:id>/', views.message_view, name='message_detail'),
    path('messages/send/', views.send_message, name='send_message'),
    
    # IMPORTANT: Conversation uses UUID, not int
    path('send-message/<uuid:conversation_id>/', 
         views.send_message_to_conversation, 
         name='send_message_to_conversation'),

    path('send-message/to/<str:recipient_username>/', 
         views.send_message_to_user, 
         name='send_message_to_user'),

    # AI chat routes
    path('ai/start/', views.start_ai_conversation, name='start_ai_chat'),
    path('start-ai-conversation/', views.start_ai_conversation, name='start_ai_conversation'),

    # Admin / test routes
    path('admin/test-gemini/', views.test_gemini_api, name='admin_test_gemini'),
    path('test-gemini-api/', views.test_gemini_api, name='test_gemini_api'),

    # Contact routes
    path('contact/', views.contact_form, name='contact_form'),
    path('contact-admin/', views.contact_admin, name='contact_admin'),
    path('contact/success/', lambda r: render(r, 'core/contact_success.html'), name='contact_success'),

    # Pages
    path('about/', views.about_view, name='about'),
    path('services/', views.services_view, name='services'),
    path('inbox/', views.inbox, name='inbox'),
    path('messages/inbox/', views.inbox, name='messages_inbox'),

    # Home page (should be last)
    path('', views.index_view, name='index'),
     path("core/", RedirectView.as_view(url="/")),
     
]
