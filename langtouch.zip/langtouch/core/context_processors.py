from django.contrib.contenttypes.models import ContentType
from .models import SEO

def seo_context(request):
    """Add global SEO data to all templates"""
    context = {
        "seo": None,
        "global_seo": {
            "site_name": "Langtouch Language Services",
            "default_image": request.build_absolute_uri("/static/images/og-default.jpg"),
            "theme_color": "#3b82f6",
        }
    }

    path = request.path_info

    # Handle service SEO safely
    if path.startswith("/services/"):
        try:
            from services.models import Service  # FIXED import
            
            parts = [p for p in path.split("/") if p]  # remove empty items
            
            # Expecting /services/<slug>/
            if len(parts) >= 2:
                service_slug = parts[1]
                service = Service.objects.filter(slug=service_slug).first()
                
                if service:
                    content_type = ContentType.objects.get_for_model(service)
                    seo_obj = SEO.objects.filter(
                        content_type=content_type,
                        object_id=service.id
                    ).first()

                    context["seo"] = seo_obj

        except Exception as e:
            print("SEO CONTEXT ERROR:", e)  # Shows the error in console when DEBUG=True
            pass

    return context
