from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.conf import settings
from django.utils import timezone
import uuid


# ---------------------------------------------------------
# SEO MODEL
# ---------------------------------------------------------
class SEO(models.Model):
    page_type = models.CharField(max_length=100)
    meta_title = models.CharField(max_length=60)
    meta_description = models.CharField(max_length=160)
    meta_keywords = models.CharField(max_length=255, blank=True)
    canonical_url = models.URLField(blank=True, null=True)
    robots_meta = models.CharField(max_length=50, blank=True)
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # Generic relation
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True, blank=True)
    object_id = models.PositiveIntegerField(null=True, blank=True)
    content_object = GenericForeignKey('content_type', 'object_id')

    # Open Graph
    og_title = models.CharField(max_length=255, blank=True)
    og_description = models.TextField(blank=True)
    og_type = models.CharField(max_length=50, blank=True)
    og_image_url = models.URLField(blank=True)
    og_image_alt = models.CharField(max_length=255, blank=True)
    og_image_width = models.PositiveIntegerField(blank=True, null=True)
    og_image_height = models.PositiveIntegerField(blank=True, null=True)

    # Twitter
    twitter_card = models.CharField(max_length=50, blank=True)
    twitter_site = models.CharField(max_length=100, blank=True)
    twitter_creator = models.CharField(max_length=100, blank=True)
    twitter_title = models.CharField(max_length=255, blank=True)
    twitter_description = models.TextField(blank=True)
    twitter_image_url = models.URLField(blank=True)

    # Organization
    organization_name = models.CharField(max_length=255, blank=True)
    organization_phone = models.CharField(max_length=50, blank=True)
    organization_logo = models.URLField(blank=True)
    address_street = models.CharField(max_length=255, blank=True)
    address_city = models.CharField(max_length=100, blank=True)
    address_region = models.CharField(max_length=100, blank=True)
    address_postal = models.CharField(max_length=20, blank=True)
    address_country = models.CharField(max_length=100, blank=True)
    area_served = models.CharField(max_length=255, blank=True)
    area_served_name = models.CharField(max_length=255, blank=True)

    # Social
    facebook_url = models.URLField(blank=True)
    twitter_url = models.URLField(blank=True)
    linkedin_url = models.URLField(blank=True)
    instagram_url = models.URLField(blank=True)

    # Ratings
    rating_value = models.FloatField(blank=True, null=True)
    review_count = models.PositiveIntegerField(blank=True, null=True)
    low_price = models.FloatField(blank=True, null=True)
    high_price = models.FloatField(blank=True, null=True)
    price_range = models.CharField(max_length=50, blank=True)

    # Verification
    google_site_verification = models.CharField(max_length=255, blank=True)
    bing_site_verification = models.CharField(max_length=255, blank=True)
    yandex_site_verification = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return self.meta_title


# ---------------------------------------------------------
# CONVERSATION MODEL
# ---------------------------------------------------------
class Conversation(models.Model):
    participant1 = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="conversations_as_p1"
    )
    participant2 = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="conversations_as_p2"
    )

    last_message_timestamp = models.DateTimeField(default=timezone.now)

    class Meta:
        unique_together = ("participant1", "participant2")
        indexes = [
            models.Index(fields=["last_message_timestamp"]),
        ]

    def save(self, *args, **kwargs):
        # Normalize ordering for uniqueness enforcement
        if self.participant1_id and self.participant2_id:
            if self.participant1_id > self.participant2_id:
                self.participant1, self.participant2 = self.participant2, self.participant1
        super().save(*args, **kwargs)

    def __str__(self):
        return f"Conversation: {self.participant1} ↔ {self.participant2}"

    @classmethod
    def get_or_create_conversation(cls, user1, user2):
        # Normalize ordering
        if user1.id > user2.id:
            user1, user2 = user2, user1

        convo, created = cls.objects.get_or_create(
            participant1=user1,
            participant2=user2
        )
        return convo


# ---------------------------------------------------------
# MESSAGE MODEL
# ---------------------------------------------------------
class Message(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)

    sender = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="sent_messages"
    )

    conversation = models.ForeignKey(
        Conversation,
        on_delete=models.CASCADE,
        related_name="messages"
    )

    body = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']

    def __str__(self):
        return f"Message from {self.sender}"


# ---------------------------------------------------------
# CONTACT MESSAGE MODEL
# ---------------------------------------------------------
class ContactMessage(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField()
    subject = models.CharField(max_length=255)
    message = models.TextField()
    reply = models.TextField(blank=True)
    replied = models.BooleanField(default=False)
    received_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.subject} from {self.name}"


# ---------------------------------------------------------
# NOTIFICATION MODEL
# ---------------------------------------------------------
class Notification(models.Model):
    STATUS_CHOICES = [
        ('unread', 'Unread'),
        ('read', 'Read'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='notifications'
    )
    message = models.TextField()
    notification_type = models.CharField(max_length=100)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='unread')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Notification for {self.user}"


# ---------------------------------------------------------
# RATING MODEL
# ---------------------------------------------------------
class Rating(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='ratings'
    )
    score = models.PositiveIntegerField()
    feedback = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.score} by {self.user}"
