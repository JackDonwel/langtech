# core/templatetags/inbox_tags.py
from django.db.models import Q
from django import template
from core.models import Message

register = template.Library()

@register.simple_tag
def get_unread_count(user):
    """Return total number of messages for a user."""
    if not user.is_authenticated:
        return 0

    return Message.objects.filter(
        Q(conversation__participant1=user) |
        Q(conversation__participant2=user)
    ).exclude(sender=user).count()



@register.simple_tag
def get_latest_message(conversation):
    """Return most recent message in a conversation."""
    return conversation.messages.order_by('-created_at').first()
