from django.contrib import admin
from .models import Project

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ['title', 'user', 'service', 'status', 'deadline', 'created_at']
    list_filter = ['status', 'service']
    search_fields = ['title', 'description', 'user__email']
