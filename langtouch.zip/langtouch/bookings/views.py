# booking/views.py

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db import IntegrityError
from .forms import BookingForm
from .models import Booking

@login_required
def booking_create(request):
    """
    Handles the creation of a new booking.
    """
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            try:
                booking = form.save(commit=False)
                booking.user = request.user
                booking.platform = 'website'  # Default to website platform
                booking.status = 'pending'    # Default to pending status
                booking.save()
                messages.success(request, 'Your booking has been successfully created!')
                return redirect('my_bookings')
            except IntegrityError:
                messages.error(request, 'This timeslot is already booked. Please choose another one.')
                return render(request, 'booking_form.html', {'form': form})
        else:
            # Re-render form with errors
            return render(request, 'booking_form.html', {'form': form})
    else:
        form = BookingForm()
    
    return render(request, 'booking_form.html', {'form': form})

@login_required
def my_bookings(request):
    """
    Displays a list of all bookings for the logged-in user.
    """
    user_bookings = Booking.objects.filter(user=request.user).order_by('-booking_date', '-timeslot')
    context = {
        'bookings': user_bookings
    }
    return render(request, 'bookings/my_bookings.html', context)

def schedule_call(request):
    # integration with Calendly/Zoho later
    return render(request, "bookings/schedule.html")

