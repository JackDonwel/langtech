# booking/forms.py

from django import forms
from .models import Booking, Service

class BookingForm(forms.ModelForm):
    # Fetch available services to populate the dropdown
    service = forms.ModelChoiceField(
        queryset=Service.objects.all(),
        widget=forms.Select(attrs={'class': 'w-full p-2 border rounded-md focus:ring focus:ring-blue-500'})
    )
    
    # Use a date input with a custom widget for better UX
    booking_date = forms.DateField(
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'w-full p-2 border rounded-md focus:ring focus:ring-blue-500'})
    )
    
    # Use a time input with a custom widget
    timeslot = forms.TimeField(
        widget=forms.TimeInput(attrs={'type': 'time', 'class': 'w-full p-2 border rounded-md focus:ring focus:ring-blue-500'})
    )

    class Meta:
        model = Booking
        fields = ['service', 'booking_date', 'timeslot']