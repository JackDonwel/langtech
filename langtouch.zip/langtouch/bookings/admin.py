# booking/admin.py

from django.contrib import admin
from .models import Service, Booking

# Register the Service model first
@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'duration_minutes')
    search_fields = ('name',)

# Customize the Booking model's admin display
@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ('user', 'service', 'booking_date', 'timeslot', 'status', 'platform', 'created_at')
    list_filter = ('status', 'platform', 'booking_date')
    search_fields = ('user__username', 'service__name')
    date_hierarchy = 'booking_date'
    readonly_fields = ('created_at', 'updated_at')
