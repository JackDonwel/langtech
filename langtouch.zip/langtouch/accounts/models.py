from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.core.exceptions import ValidationError
import uuid


class UserManager(BaseUserManager):
    def _validate_user_data(self, email, username, **extra_fields):
        """Validate user data before creation"""
        if not email:
            raise ValidationError(_("The Email field is required."))
        if not username:
            raise ValidationError(_("The Username field is required."))
        
        email = self.normalize_email(email)
        if self.filter(email=email).exists():
            raise ValidationError(_("A user with this email already exists."))
        if self.filter(username=username).exists():
            raise ValidationError(_("A user with this username already exists."))
        
        return email

    def create_user(self, email, username, password=None, **extra_fields):
        """
        Create and return a regular user with an email, username and password.
        """
        email = self._validate_user_data(email, username, **extra_fields)
        
        user = self.model(
            email=email,
            username=username,
            **extra_fields
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, username, password=None, **extra_fields):
        """
        Create and return a superuser with admin permissions.
        """
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)

        if extra_fields.get('is_staff') is not True:
            raise ValidationError(_('Superuser must have is_staff=True.'))
        if extra_fields.get('is_superuser') is not True:
            raise ValidationError(_('Superuser must have is_superuser=True.'))

        return self.create_user(email, username, password, **extra_fields)

    def get_by_natural_key(self, username):
        """Allow login via username OR email"""
        try:
            return self.get(username=username)
        except self.model.DoesNotExist:
            return self.get(email=username)


class User(AbstractBaseUser, PermissionsMixin):
    """
    Custom User model supporting email as primary identifier.
    Includes optional personal information and audit fields.
    """
    # Identification fields
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(
        _('email address'),
        unique=True,
        db_index=True,
        help_text=_('Required. Must be a valid email address.')
    )
    username = models.CharField(
        _('username'),
        max_length=150,
        unique=True,
        db_index=True,
        help_text=_('Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.')
    )
    
    # Personal information (optional)
    first_name = models.CharField(
        _('first name'),
        max_length=30,
        blank=True,
        help_text=_('Optional. Maximum 30 characters.')
    )
    last_name = models.CharField(
        _('last name'),
        max_length=150,
        blank=True,
        help_text=_('Optional. Maximum 150 characters.')
    )
    
    # Status fields
    is_active = models.BooleanField(
        _('active'),
        default=True,
        help_text=_(
            'Designates whether this user should be treated as active. '
            'Unselect this instead of deleting accounts.'
        )
    )
    is_staff = models.BooleanField(
        _('staff status'),
        default=False,
        help_text=_('Designates whether the user can log into this admin site.')
    )
    
    # Audit fields
    date_joined = models.DateTimeField(
        _('date joined'),
        default=timezone.now,
        editable=False
    )
    updated_at = models.DateTimeField(
        _('last updated'),
        auto_now=True,
        help_text=_('Date and time when this user was last modified.')
    )
    last_login = models.DateTimeField(
        _('last login'),
        blank=True,
        null=True,
        help_text=_('Last time the user logged in.')
    )
    
    # Verification fields (optional - for future use)
    email_verified = models.BooleanField(
        _('email verified'),
        default=False,
        help_text=_('Designates whether this user has verified their email address.')
    )
    
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']
    
    objects = UserManager()
    
    class Meta:
        verbose_name = _('user')
        verbose_name_plural = _('users')
        ordering = ['-date_joined']
        indexes = [
            models.Index(fields=['email']),
            models.Index(fields=['username']),
            models.Index(fields=['date_joined']),
        ]
    
    def __str__(self):
        return self.email
    
    def get_full_name(self):
        """
        Return the first_name plus the last_name, with a space in between.
        """
        full_name = f"{self.first_name} {self.last_name}".strip()
        return full_name if full_name else self.username
    
    def get_short_name(self):
        """Return the short name for the user."""
        return self.first_name or self.username
    
    def has_role(self, role_name):
        """Check if user has a specific role."""
        return self.roles.filter(name=role_name).exists()
    
    def get_roles(self):
        """Get all role names for this user."""
        return self.userrole_set.select_related('role').values_list('role__name', flat=True)
    
    def add_role(self, role):
        """Add a role to the user."""
        from .models import UserRole  # Import here to avoid circular imports
        UserRole.objects.get_or_create(user=self, role=role)
    
    def remove_role(self, role):
        """Remove a role from the user."""
        from .models import UserRole
        UserRole.objects.filter(user=self, role=role).delete()
    
    @property
    def is_email_verified(self):
        """Check if email is verified."""
        return self.email_verified
    
    def clean(self):
        """Custom validation for the User model."""
        super().clean()
        if self.email:
            self.email = self.__class__.objects.normalize_email(self.email)


class Role(models.Model):
    """
    Role model for grouping users and assigning permissions.
    Example roles: Admin, Client, Linguist, Moderator
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(
        _('role name'),
        max_length=100,
        unique=True,
        help_text=_('Name of the role (e.g., Admin, Client, Linguist).')
    )
    description = models.TextField(
        _('description'),
        blank=True,
        help_text=_('Detailed description of the role and its responsibilities.')
    )
    is_default = models.BooleanField(
        _('default role'),
        default=False,
        help_text=_('Whether this role should be assigned to new users by default.')
    )
    
    # Audit fields
    created_at = models.DateTimeField(
        _('created at'),
        default=timezone.now,
        editable=False
    )
    updated_at = models.DateTimeField(
        _('updated at'),
        auto_now=True
    )
    
    class Meta:
        verbose_name = _('role')
        verbose_name_plural = _('roles')
        ordering = ['name']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['is_default']),
        ]
    
    def __str__(self):
        return self.name
    
    def user_count(self):
        """Return the number of users with this role."""
        return self.user_set.count()
    
    def get_permissions(self):
        """Get all permissions for this role."""
        return self.permissions.values_list('permission__name', flat=True)


class UserRole(models.Model):
    """
    Junction table linking Users to Roles (Many-to-Many relationship).
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='user_roles',
        verbose_name=_('user')
    )
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name='role_users',
        verbose_name=_('role')
    )
    
    # Additional fields for role assignment context
    assigned_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='assigned_roles',
        verbose_name=_('assigned by')
    )
    assigned_at = models.DateTimeField(
        _('assigned at'),
        default=timezone.now
    )
    expires_at = models.DateTimeField(
        _('expires at'),
        null=True,
        blank=True,
        help_text=_('Optional. When this role assignment should expire.')
    )
    is_active = models.BooleanField(
        _('active'),
        default=True,
        help_text=_('Whether this role assignment is currently active.')
    )
    
    class Meta:
        verbose_name = _('user role')
        verbose_name_plural = _('user roles')
        unique_together = ('user', 'role')
        ordering = ['-assigned_at']
    
    def __str__(self):
        return f"{self.user.email} - {self.role.name}"
    
    def is_expired(self):
        """Check if the role assignment has expired."""
        if self.expires_at:
            return timezone.now() > self.expires_at
        return False


class Permission(models.Model):
    """
    System permissions that can be assigned to roles.
    Example permissions: can_create_project, can_edit_translation
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(
        _('permission name'),
        max_length=100,
        unique=True,
        help_text=_('System name of the permission (e.g., can_create_project).')
    )
    codename = models.CharField(
        _('codename'),
        max_length=100,
        unique=True,
        help_text=_('Short code for the permission (e.g., create_project).')
    )
    description = models.TextField(
        _('description'),
        blank=True,
        help_text=_('Detailed description of what this permission allows.')
    )
    category = models.CharField(
        _('category'),
        max_length=50,
        default='general',
        help_text=_('Category for grouping permissions (e.g., project, translation, user).')
    )
    
    # Audit fields
    created_at = models.DateTimeField(_('created at'), default=timezone.now)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    
    class Meta:
        verbose_name = _('permission')
        verbose_name_plural = _('permissions')
        ordering = ['category', 'name']
        indexes = [
            models.Index(fields=['codename']),
            models.Index(fields=['category']),
        ]
    
    def __str__(self):
        return self.name


class RolePermission(models.Model):
    """
    Junction table linking Roles to Permissions.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    role = models.ForeignKey(
        Role,
        on_delete=models.CASCADE,
        related_name='role_permissions',
        verbose_name=_('role')
    )
    permission = models.ForeignKey(
        Permission,
        on_delete=models.CASCADE,
        related_name='permission_roles',
        verbose_name=_('permission')
    )
    
    # Additional context
    granted_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_('granted by')
    )
    granted_at = models.DateTimeField(
        _('granted at'),
        default=timezone.now
    )
    
    class Meta:
        verbose_name = _('role permission')
        verbose_name_plural = _('role permissions')
        unique_together = ('role', 'permission')
        ordering = ['-granted_at']
    
    def __str__(self):
        return f"{self.role.name} - {self.permission.name}"