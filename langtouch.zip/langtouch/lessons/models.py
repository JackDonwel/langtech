from django.db import models
from django.conf import settings


class Course(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    duration_weeks = models.PositiveIntegerField()
    certification = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    @property
    def active_enrollments(self):
        """Return only active enrollments"""
        return self.enrollments.filter(is_active=True)

    @property
    def enrolled_users(self):
        """Shortcut to get all users currently enrolled"""
        return settings.AUTH_USER_MODEL.objects.filter(
            enrollments__course=self, enrollments__is_active=True
        )


class Enrollment(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="enrollments"
    )
    course = models.ForeignKey(
        Course,
        on_delete=models.CASCADE,
        related_name="enrollments"
    )
    payment = models.OneToOneField(
        "payments.Payment",   # string reference avoids circular import
        null=True,
        blank=True,
        on_delete=models.SET_NULL,
        related_name="enrollment"
    )
    enrolled_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        unique_together = ("user", "course")  # ✅ Prevent duplicate enrollments
        ordering = ["-enrolled_at"]  # Show latest enrollments first

    def __str__(self):
        return f"{self.user.email} -> {self.course.title}"

    @property
    def is_confirmed(self):
        """Check if enrollment is tied to a confirmed payment"""
        return bool(self.payment and self.payment.is_confirmed)
