from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .models import Course

@login_required
def course_list(request):
    """List all available courses."""
    courses = Course.objects.all()
    return render(request, "lessons/course_list.html", {"courses": courses})

@login_required
def course_detail(request, course_id):
    """Show details for a single course."""
    course = get_object_or_404(Course, id=course_id)
    return render(request, "lessons/course_detail.html", {"course": course})

@login_required
def has_confirmed_payment(user, course):
    """Helper to check if user has confirmed payment for a course."""
    try:
        from payments.models import Payment
        return Payment.objects.filter(
            user=user,
            course=course,
            is_confirmed=True,
            status="Completed"
        ).exists()
    except Exception:
        return False


@login_required
def enroll_course(request, course_id):
    """
    Enrollment flow:
    1. If user already enrolled → redirect to course detail.
    2. If user has confirmed payment → enroll + redirect.
    3. Otherwise → redirect to payment selection page.
    """
    course = get_object_or_404(Course, id=course_id)

    # Already enrolled
    if request.user in course.enrolled_students.all():
        messages.info(request, "✅ You are already enrolled in this course.")
        return redirect("lessons:course_detail", course_id=course.id)

    # Has a confirmed payment?
    if has_confirmed_payment(request.user, course):
        course.enrolled_students.add(request.user)
        messages.success(request, "🎉 Payment confirmed — you are now enrolled!")
        return redirect("lessons:course_detail", course_id=course.id)

    # No confirmed payment → send to payment selection
    messages.warning(
        request,
        "⚠️ You must complete payment before enrolling. Redirecting to payment options..."
    )
    return redirect("payments:select_method", object_type="course", object_id=course.id)
