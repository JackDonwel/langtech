from django.contrib import admin
from .models import Course, Enrollment


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ("title", "price", "duration_weeks", "certification", "created_at")
    search_fields = ("title", "description")
    list_filter = ("certification", "created_at")
    ordering = ("-created_at",)


@admin.register(Enrollment)
class EnrollmentAdmin(admin.ModelAdmin):
    list_display = ("user", "course", "payment", "is_active", "enrolled_at")
    search_fields = ("user__email", "course__title")
    list_filter = ("is_active", "enrolled_at")
    ordering = ("-enrolled_at",)


