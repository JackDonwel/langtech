from django.urls import path
from . import views

app_name = "quotes"

urlpatterns = [
    path("request/", views.quote_request_view, name="quote_request"),
    path("success/", views.quote_success_view, name="quote_success"),  # 👈 add this
]

