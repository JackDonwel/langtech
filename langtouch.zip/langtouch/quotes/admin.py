from django.contrib import admin
from .models import QuoteRequest

@admin.register(QuoteRequest)
class QuoteRequestAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'service', 'status', 'created_at']
    list_filter = ['status', 'service']
    search_fields = ['name', 'email', 'language_from', 'language_to']
    ordering = ['-created_at']